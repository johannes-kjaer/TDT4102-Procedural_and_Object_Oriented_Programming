

string getCapital(const string& country);

void debuggerMain();