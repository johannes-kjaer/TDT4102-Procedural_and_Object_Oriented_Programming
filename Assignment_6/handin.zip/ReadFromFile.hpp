#pragma once
#include "std_lib_facilities.h"


void saveToFile(string filename);

void includeLineNumbers(string file);

