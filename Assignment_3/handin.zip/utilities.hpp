# pragma once

int psrand();

int randomWithlimits(int lowerBound, int upperBound);








