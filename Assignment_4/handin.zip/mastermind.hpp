#pragma once
#include "std_lib_facilities.h"
#include "utilities.hpp"
#include "mastermind.hpp"

// 4a)
bool playMastermind();

int checkCharacters(string code, string guess);
int checkPositions(string code, string guess);



