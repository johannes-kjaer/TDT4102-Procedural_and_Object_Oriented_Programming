#pragma once



void testCallByValue();

void testCallByReference();

void testSwapNumbers(int a, int b);

void testStudentStruct();

void testString();

void testReadInput();

